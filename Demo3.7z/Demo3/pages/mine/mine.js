//mine.js
//获取应用实例
const app = getApp()

Page({
  data: {
    menu: [{
      'title': '我的清单',
      'url': '../../pages/mylist/mylist'
    }, {
      'title': '我的日记',
      'url': '../../pages/mydiary/mydiary'
    }, {
      'title': '关于Philtrip',
      'url': '../../pages/about/about'
    }]


  },


})
