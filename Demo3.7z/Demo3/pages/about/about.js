Page({

  /**
   * 页面的初始数据
   */
 
    data: {
      name1:"褚建红",
      name2:"陶曦",
      name3:"马玉多",
      imagePath:"/images/philtrip.jpg",
      developer:"开发者",
      viewPath:"http://www.oursparkspace.cn/?p=38537",
      viewPlace:"火花空间"
    },
  

})