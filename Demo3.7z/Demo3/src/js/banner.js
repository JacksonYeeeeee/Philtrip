var bannerList = ['../../src/images/1.jpg', '../../src/images/2.jpg', '../../src/images/3.jpg','../../src/images/4.jpg'];
module.exports = {
  bannerList: bannerList
}