//app.js
App({
  globalData: {
    userInfo: null,
    journalName:"",
    male:0,
    female:0,
    kid:0,
    journalStart:0,
    journalEnd:0,
    date:'2018-07-20',
    journalCata:0,
    journalAc:"",
  }
})